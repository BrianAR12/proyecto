from flask import Flask, render_template,request, redirect, url_for, flash
from flaskext.mysql import MySQL
import pymysql

app = Flask(__name__)
app.config['MYSQL_DATABASE_HOST']='localhost'
app.config['MYSQL_DATABASE_USER']='root'
app.config['MYSQL_DATABASE_PASSWORD']='1234'
app.config['MYSQL_DATABASE_DB']='inventario'

mysql = MySQL()
mysql.init_app(app)


#sesión protegida
app.secret_key  = 'miSesionSecreta'
con = mysql.connect()
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/proveedores', methods =['GET','POST'])
def papa():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute('SELECT * FROM proveedores')
        data = query.fetchall()
        return render_template('agregarproveedor.html', variable = data)

@app.route('/agregar', methods =['GET','POST'])
def agregar():     
    if request.method == 'POST':
        codigo = request.form['codigo']
        Nombre = request.form['Nombre']
        rfc = request.form['rfc']
        Email = request.form['Email']
        Telefono = request.form['Telefono']
        fecha = request.form['fecha']
        print(codigo)
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("INSERT INTO proveedores VALUES ( %s,'%s','%s','%s',%s,'%s')" %(codigo,Nombre,rfc,Email,Telefono,fecha))             
        con.commit();
        flash('Registro aregado crrectamente')
        return redirect(url_for('papa'))
    
"""
@app.route('/eliminar/<string:id>')
def eliminar(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute(""""""DELETE FROM departamento where codDepartamento  = ('%s')"""""" % (id))
    con.commit();
    flash('Registro borrado crrectamente')
    return redirect(url_for('index'))


@app.route('/editar/<id>')
def editar(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute(""""""SELECT * FROM departamento WHERE codDepartamento = ('%s') """""" %(id))
    datoEditar = query.fetchall()
    return render_template('editar.html', datos = datoEditar[0])

@app.route('/update/<id>',methods = ['GET','POST'])
def update(id):
    if request.method == 'POST':
        codDepartamento = request.form['codDepartamento']
        nombreDepartamento = request.form['nombreDepartamento']
        presupDepartamento = request.form['presupDepartamento']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute(""""""UPDATE departamento
                    SET
                    codDepartamento =  %s,
                    nombreDepartamento = '%s',
                    presupDepartamento = %s
                    WHERE codDepartamento = %s """"""%(codDepartamento,nombreDepartamento,presupDepartamento,id))
        con.commit();
        flash('Registro se actualizó crrectamente')
        return redirect(url_for('index'))   """    

if __name__ == '__main__':
    app.run(port =3000, debug = True)
