from flask import Flask, render_template,request, redirect, url_for, flash, jsonify
from flaskext.mysql import MySQL
import pymysql

app = Flask(__name__)
app.config['MYSQL_DATABASE_HOST']='localhost'
app.config['MYSQL_DATABASE_USER']='root'
app.config['MYSQL_DATABASE_PASSWORD']='1234'
app.config['MYSQL_DATABASE_DB']='proyecto'

mysql = MySQL()
mysql.init_app(app)


#sesión protegida
app.secret_key  = 'miSesionSecreta'
con = mysql.connect()
@app.route('/')
def index():
    return render_template('index.html')
######################### L O   G   I   N  #####################################   

######################### MODELO EOQ #####################################  

 
@app.route('/inventario', methods =['GET','POST'])
def inventario():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        sql = ('SELECT * FROM productos')
        query.execute(sql)    
        data = query.fetchall()
        return render_template('ModeloEOQ.html', variable = data)
        
@app.route('/TablaInventario', methods =['GET','POST'])
def TablaInventario():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        sql = ('SELECT p.descripcion, e.cantidad, e,FechaInicio, FechaFin FROM inventario e INNER JOIN productos p on e.CodProducto = p.CodProducto')
        query.execute(sql)
        data = query.fetchall()
        return render_template('TablaEntradas.html', variable = data)


   
    
@app.route('/elegirProducto', methods =['GET','POST'])        
def elegirProducto():
    if request.method == 'POST':
        producto = request.form['producto'] 
        fechaInicio = request.form['fechaInicio']
        fechaFin = request.form['fechaFin']
        #total = request.form['product']
        query = con.cursor(pymysql.cursors.DictCursor)
        query2 = con.cursor(pymysql.cursors.DictCursor)
        sql = (" SELECT SUM(cantidad) AS total FROM salidas WHERE CodProducto = ('%s') AND FechaSalida >= ('%s') AND FechaSalida <= ('%s') " %(producto, fechaInicio,fechaFin))
        #sql2 = (" SELECT DATEDIFF('%s','%s')" %(fechaFin,fechaInicio))   <----- Funcionando
        query2.execute(sql)
        data = query2.fetchall()
        #query.execute("INSERT INTO inventario (CodProducto,FechaInicio, FechaFin, cantidad) VALUES ( %s,'%s','%s',%s)" %(id,fechaInicio,fechaFin,data))
        query.execute("INSERT INTO inventario VALUES (%s,'%s','%s',%s)" %(producto,fechaInicio,fechaFin,data))        
        #query.execute("INSERT INTO inventario VALUES (%s,'%s','%s',%s)" %(id,fechaInicio,fechaFin,data))   
        con.commit();
        flash('Entrada agregada correctamente')
        return redirect(url_for('compras'))        
#INSERT INTO inventario(CodProducto, cantidad) values (1,(SELECT SUM(cantidad) FROM entradas WHERE CodProducto = 1 AND FechaEntrada >= '2022-11-12' AND FechaEntrada <= '2022-11-18'));

        
        
        
        
        
        
'''        
        query1 = con.cursor(pymysql.cursors.DictCursor)
        query2 = con.cursor(pymysql.cursors.DictCursor)
        #sql2 = (" SELECT SUM(cantidad) AS total FROM salidas WHERE CodProducto = ('%s') AND FechaSalida >= ('%s') AND FechaSalida <= ('%s') " %(id, fechainicio,fechafin))
        sql2 = (" SELECT SUM(cantidad) AS total FROM salidas WHERE CodProducto = ('%s') AND FechaSalida >= '2022-11-12' AND FechaSalida <= '2022-11-14' " %(id))
        #sql4 = (" SELECT inventario  fechaInicio = ('%s') AND FechaSalida >= ('%s') AND FechaSalida <= ('%s') " %(id, fechainicio,fechafin))
        sql = (" SELECT * FROM salidas WHERE CodProducto = ('%s') " %(id))
        query.execute(sql)    
        datoEditar = query.fetchall()
        sql1 = (" SELECT * FROM productos WHERE CodProducto = ('%s') " %(id))
        query1.execute(sql1)    
        data = query1.fetchall()
        query2.execute(sql2)    
        data2 = query2.fetchall()
        #que = con.cursor(pymysql.cursors.DictCursor)
       # que.execute("INSERT INTO totales VALUES (%s)" %('total')) 
'''     
        
       
        #return render_template('EOQ.html', datos = datoEditar, variable = data, cantidad = data2)
        
        
        
        
'''      
INSERT INTO inventario(CodProducto, cantidad) values (1,(SELECT SUM(cantidad) FROM entradas WHERE CodProducto = 1 AND FechaEntrada >= '2022-11-12' AND FechaEntrada <= '2022-11-18'),);

                  sql2 = ("SELECT SUM(cantidad) FROM entradas WHERE CodProducto = producto AND FechaEntrada >= %('fechainicio') AND FechaEntrada <= 'fechafin'")

        cur.execute("INSERT INTO 'login'('fname','lname','username','password','email','question','answer') VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",(fname,lname,username,password,cpassword,email,selection,answer))        
        print "Registered"
'''


######################### P     R   O   V   E   E   D   O   R   E   S #####################################   
    
@app.route('/proveedores', methods =['GET','POST'])
def proveedores():
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute('SELECT * FROM proveedores')
    data = query.fetchall()
    return render_template('TablaProveedores.html', variable = data)

@app.route('/nuevoProveedor', methods =['GET','POST'])
def nuevoProveedor():
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute('SELECT * FROM proveedores')
    data = query.fetchall()
    return render_template('agregarProveedor.html', variable = data)
    
@app.route('/agregarProveedor', methods =['GET','POST'])
def agregarProveedor():     
    if request.method == 'POST':
        codigo = request.form['codigo']
        Nombre = request.form['Nombre']
        rfc = request.form['rfc']
        Email = request.form['Email']
        Telefono = request.form['Telefono']
        fecha = request.form['fecha']
        print(codigo)
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("INSERT INTO proveedores VALUES ( %s,'%s','%s','%s',%s,'%s')" %(codigo,Nombre,rfc,Email,Telefono,fecha))             
        con.commit();
        flash('Proveedor agregado correctamente')
        return redirect(url_for('proveedores'))

@app.route('/eliminarProveedor/<string:id>')
def eliminarProveedor(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute("DELETE FROM proveedores where CodProveedor   = ('%s')" % (id))
    con.commit();
    flash('Proveedor eliminado correctamente')
    return redirect(url_for('proveedores'))

@app.route('/editarProveedor/<id>')
def editarProveedor(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute(" SELECT * FROM proveedores WHERE CodProveedor = ('%s') " %(id))
    datoEditar = query.fetchall()
    return render_template('editarProveedor.html', datos = datoEditar[0])
    
@app.route('/actualizarProveedor/<id>',methods = ['GET','POST'])
def actualizarProveedor(id):
    if request.method == 'POST':
        CodProveedor = request.form['CodProveedor']
        nombre = request.form['nombre']
        RFC = request.form['RFC']
        email = request.form['email']
        telefono = request.form['telefono']
        FechaAlta = request.form['FechaAlta']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("""UPDATE proveedores
                    SET
                    CodProveedor =  %s,
                    nombre = '%s',
                    RFC = '%s',
                    email =  '%s',
                    telefono = %s,
                    FechaAlta = '%s'
                    WHERE CodProveedor = %s """%(CodProveedor,nombre,RFC,email,telefono,FechaAlta,id))
        con.commit();
        flash('El proveedor se actualizó correctamente')
        return redirect(url_for('proveedores')) 
    


######################### P     R   O   D   U   C   T   O   S #####################################   
        
@app.route('/productos', methods =['GET','POST'])
def productos():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        sql = ('SELECT p.CodProducto, p.descripcion, c.categoria, p.Cantidad, p.FechaAlta, a.nombre FROM productos p INNER JOIN categoria c on p.idCategoria = c.idCategoria INNER JOIN proveedores a on p.CodProveedor = a.CodProveedor')
        query.execute(sql)
        data = query.fetchall()
        query2 = con.cursor(pymysql.cursors.DictCursor)
        sql2 = ('SELECT c.nombre FROM proveedores c INNER JOIN productos p on c.CodProveedor = p.CodProveedor')
        query2.execute(sql2)
        result = query2.fetchall()
        return render_template('TablaProductos.html', variable = data, consulta = result)
        
@app.route('/nuevoProducto', methods =['GET','POST'])
def nuevoProducto():
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute('SELECT * FROM categoria')
    data = query.fetchall() 
    query2 = con.cursor(pymysql.cursors.DictCursor)
    sql2 = ('SELECT * FROM proveedores ')
    query2.execute(sql2)
    result = query2.fetchall()
    return render_template('agregarProducto.html', variable = data, variable2 = result)

@app.route('/agregarProducto', methods =['GET','POST'])
def agregarProducto():     
    if request.method == 'POST':
        codigo_produc = request.form['codigo_produc']
        descripcion = request.form['descripcion']
        categoria = request.form['categoria']
        cantidad = (0)
        cod_proveedor = request.form['cod_proveedor']
        fechaAlta = request.form['fechaAlta']
        print(codigo_produc)
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("INSERT INTO productos VALUES ( %s,'%s',%s,%s,%s,'%s')" %(codigo_produc,descripcion,categoria,cantidad,cod_proveedor,fechaAlta))             
        con.commit();
        flash('Producto agregado correctamente')
        return redirect(url_for('productos'))

@app.route('/eliminarProducto/<string:id>')
def eliminarProducto(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute("DELETE FROM productos where CodProducto  = ('%s')" % (id))
    con.commit();
    flash('Producto eliminado correctamente')
    return redirect(url_for('productos'))
    
@app.route('/editarProducto/<id>')
def editarProducto(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute(" SELECT * FROM productos p INNER JOIN categoria c on p.idCategoria = c.idCategoria WHERE p.CodProducto = ('%s') " %(id))
    datoEditar = query.fetchall()
    
    sql2 = ("SELECT * FROM categoria ")
    query2 = con.cursor(pymysql.cursors.DictCursor)
    query2.execute(sql2)
    resultadoSQL = query2.fetchall()
    
    query4 = con.cursor(pymysql.cursors.DictCursor)
    query4.execute(" SELECT * FROM productos p INNER JOIN proveedores c on p.CodProveedor = c.CodProveedor WHERE p.CodProducto = ('%s') " %(id))
    datoEditar2 = query4.fetchall()
    
    sql3 = ("SELECT * FROM proveedores ")
    query3 = con.cursor(pymysql.cursors.DictCursor)
    query3.execute(sql3)
    resultadoSQL2 = query3.fetchall()
    return render_template('editarProducto.html', datos = datoEditar[0], datos2 = resultadoSQL,datos3 = resultadoSQL2, datpov = datoEditar2[0])
    
@app.route('/actualizarProducto/<id>',methods = ['GET','POST'])
def actualizarProducto(id):
    if request.method == 'POST':
        codigo_produc = request.form['codigo_produc']
        descripcion = request.form['descripcion']
        categoria = request.form['categoria']
        cantidad = request.form['cantidad']
        cod_proveedor = request.form['cod_proveedor']
        fechaAlta = request.form['fechaAlta']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("""UPDATE productos SET
                    CodProducto =  %s,
                    descripcion = '%s',
                    idCategoria = %s,
                    Cantidad = %s,
                    CodProveedor =  %s,
                    FechaAlta =  '%s'
                    WHERE CodProducto = %s """%(codigo_produc,descripcion,categoria,cantidad,cod_proveedor,fechaAlta,id))
        con.commit();
        flash('La entrada se actualizó correctamente')
        return redirect(url_for('compras'))
    
     
        
######################### E     N    T       R    A      D      A    S #####################################    
@app.route('/compras', methods =['GET','POST'])
def compras():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        sql = ('SELECT e.IdEntrada, p.descripcion, e.cantidad, e.FechaEntrada FROM entradas e INNER JOIN productos p on e.CodProducto = p.CodProducto')
        query.execute(sql)
        data = query.fetchall()
        return render_template('TablaEntradas.html', variable = data)

@app.route('/nuevaEntrada', methods =['GET','POST'])
def nuevaEntrada():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        query2 = con.cursor(pymysql.cursors.DictCursor)
        query.execute('SELECT * FROM productos;')
        query2.execute('SELECT * FROM categoria;')
        data2 = query2.fetchall()
        data = query.fetchall()
        return render_template('agregarCompra.html', catego = data2, product = data)     
    
        
@app.route('/agregarCompra', methods =['GET','POST'])
def agregarCompra():     
    if request.method == 'POST':
        codigo_compra = request.form['codigo_compra']
        producto = request.form['producto']
        cantidad = request.form['cantidad']
        fechacom = request.form['fechacom']
        query2 = con.cursor(pymysql.cursors.DictCursor)
        query2.execute("""UPDATE productos
                    SET
                    Cantidad = Cantidad + %s
                    WHERE CodProducto = %s """%(cantidad,producto))
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("INSERT INTO entradas VALUES ( %s,%s,%s,'%s')" %(codigo_compra,producto,cantidad,fechacom))   
        con.commit();
        flash('Entrada agregada correctamente')
        return redirect(url_for('compras'))
        
@app.route('/eliminarEntrada/<string:id>')
def eliminarEntrada(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute("DELETE FROM entradas where IdEntrada   = ('%s')" % (id))
    con.commit();
    flash('Entrada eliminada correctamente')
    return redirect(url_for('compras'))

@app.route('/editarEntrada/<id>')
def editarEntrada(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    sql1 = (" SELECT * FROM entradas e INNER JOIN productos p on e.CodProducto = p.CodProducto WHERE e.IdEntrada = ('%s') " %(id))
    query.execute(sql1)
    datoEditar = query.fetchall()
    
    sql2 = ("SELECT * FROM productos ")
    query2 = con.cursor(pymysql.cursors.DictCursor)
    query2.execute(sql2)
    resultadoSQL = query2.fetchall()
    return render_template('editarEntrada.html', datos = datoEditar[0], datos2 = resultadoSQL)
  
    
@app.route('/actualizarEntrada/<id>',methods = ['GET','POST'])
def actualizarEntrada(id):
    if request.method == 'POST':
        IdEntrada = request.form['IdEntrada']
        CodProducto = request.form['CodProducto']
        cantidad = request.form['cantidad']
        FechaEntrada = request.form['FechaEntrada']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("""UPDATE entradas SET
                    IdEntrada =  %s,
                    CodProducto = %s,
                    cantidad = %s,
                    FechaEntrada =  '%s'
                    WHERE IdEntrada = %s """%(IdEntrada,CodProducto,cantidad,FechaEntrada,id))
        con.commit();
        flash('La entrada se actualizó correctamente')
        return redirect(url_for('compras'))
        
######################### S     A    L    I       D      A    S #####################################       

@app.route('/ventas', methods =['GET','POST'])
def ventas():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        sql = ('SELECT s.IdSalida, p.descripcion, s.cantidad, s.FechaSalida FROM salidas s INNER JOIN productos p on s.CodProducto = p.CodProducto')
        query.execute(sql)
        data = query.fetchall()
        return render_template('TablaSalidas.html', variable = data)


@app.route('/nuevaSalida', methods =['GET','POST'])
def nuevaSalida():
    if request.method == 'GET':
        query = con.cursor(pymysql.cursors.DictCursor)
        query2 = con.cursor(pymysql.cursors.DictCursor)
        query.execute('SELECT * FROM productos;')
        query2.execute('SELECT * FROM categoria;')
        data2 = query2.fetchall()
        data = query.fetchall()
        return render_template('agregarVenta.html', catego1 = data2)
  

@app.route('/agregarVenta', methods =['GET','POST'])
def agregarVenta():     
    if request.method == 'POST':
        codigo_venta = request.form['idsalida']
        producto = request.form['producto']
        cantidad = request.form['cantidad']
        fechaven = request.form['fechaven']
        #costoxunidad = request.form['costoxunidad']
        #costoxordenar = request.form['costoxordenar']
        #costoxmantener = request.form['costoxmantener']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute(" SELECT Cantidad FROM productos WHERE CodProducto = ('%s') " %(producto))
        data = query.fetchall()
        total  = data
        if int(cantidad) > int(total):
            flash('No tiene el stock suficiente')
            return redirect(url_for('ventas'))
        else:
            query2 = con.cursor(pymysql.cursors.DictCursor)
            query2.execute("""UPDATE productos
                    SET
                    Cantidad = Cantidad - %s
                    WHERE CodProducto = %s """%(cantidad,producto))
            query3 = con.cursor(pymysql.cursors.DictCursor)
            query3.execute("INSERT INTO salidas VALUES ( %s,%s,%s,'%s')" %(codigo_venta,producto,cantidad,fechaven))             
            con.commit();
            flash('Salida agregada correctamente')
            return redirect(url_for('ventas'))

@app.route('/eliminarSalida/<string:id>')
def eliminarSalida(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    query.execute("DELETE FROM salidas where IdSalida   = ('%s')" % (id))
    con.commit();
    flash('Salida eliminada correctamente')
    return redirect(url_for('ventas'))

@app.route('/editarSalida/<id>')
def editarSalida(id):
    query = con.cursor(pymysql.cursors.DictCursor)
    sql1 = (" SELECT * FROM salidas s INNER JOIN productos p on s.CodProducto = p.CodProducto WHERE s.IdSalida = ('%s') " %(id))
    query.execute(sql1)
    datoEditar = query.fetchall()
    
    sql2 = ("SELECT * FROM productos ")
    query2 = con.cursor(pymysql.cursors.DictCursor)
    query2.execute(sql2)
    resultadoSQL = query2.fetchall()
    return render_template('editarSalida.html', datos = datoEditar[0], datos2 = resultadoSQL)
    
    
@app.route('/actualizarSalida/<id>',methods = ['GET','POST'])
def actualizarSalida(id):
    if request.method == 'POST':
        IdSalida = request.form['IdSalida']
        CodProducto = request.form['CodProducto']
        cantidad = request.form['cantidad']
        FechaSalida = request.form['FechaSalida']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("""UPDATE salidas SET
                    IdSalida =  %s,
                    CodProducto = %s,
                    cantidad = %s,
                    FechaSalida =  '%s'
                    WHERE IdSalida = %s """%(IdSalida,CodProducto,cantidad,FechaSalida,id))
        con.commit();
        flash('La salida se actualizó correctamente')
        return redirect(url_for('ventas'))
    
######################### C     A   T   E   G   O   R   I   A   S##################################### 


@app.route('/agregarCategoria', methods =['GET','POST'])
def agregarCategoria():     
    if request.method == 'POST':
        codigo_categoria = request.form['categoria1']
        nombre = request.form['nombre']
        query = con.cursor(pymysql.cursors.DictCursor)
        query.execute("INSERT INTO categoria VALUES ( %s,'%s')" %(codigo_categoria,nombre))             
        con.commit();
        flash('Categoria agregada correctamente')
        return render_template('agregarProducto.html')
        


@app.route("/get_child_categorias", methods=["GET","POST"])
def get_child_categorias():
    cur = con.cursor(pymysql.cursors.DictCursor)
    if request.method == 'POST':
        parent_id = request.form['parent_id']
        print(parent_id)
        cur.execute("SELECT * FROM productos WHERE idCategoria = %s", [parent_id])
        productos = cur.fetchall()
    return jsonify({'htmlresponse': render_template('response.html', variable3=productos)})

@app.route("/get_child_categorias2", methods=["GET","POST"])
def get_child_categorias2():
    cur = con.cursor(pymysql.cursors.DictCursor)
    if request.method == 'POST':
        parent_id = request.form['parent_id2']
        print(parent_id)
        cur.execute("SELECT * FROM productos WHERE idCategoria = %s", [parent_id])
        productos = cur.fetchall()
        return jsonify({'htmlresponse2': render_template('response2.html', variable4=productos)})
    

if __name__ == '__main__':
    app.run(port =8000, debug = True)
